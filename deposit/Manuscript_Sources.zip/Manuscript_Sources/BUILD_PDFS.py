#!/usr/bin/env python3
"""Compile the supplied standalone LaTeX documents without network access."""
from pathlib import Path
import argparse
import shutil
import subprocess
import sys

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--include-prior', action='store_true',
                        help='also compile the three unchanged historical sources')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    engine = shutil.which('pdflatex')
    if engine is None:
        parser.error('pdflatex is required; install TeX Live with the packages listed in BUILD.md')
    jobs = [('Conditional_0116398.tex', 3),
            ('Matched_Source_Supplement.tex', 3),
            ('Verification_Guide.tex', 3),
            ('Further_Consequences.tex', 3)]
    if args.include_prior:
        jobs += [('prior_sources/Correlated_Translated_Probes.tex', 2),
                 ('prior_sources/Analytic_Foundations.tex', 3),
                 ('prior_sources/Verification_Guide.tex', 2)]
    for relative, passes in jobs:
        source = root / relative
        destination = root / 'build' / ('prior_sources' if source.parent.name == 'prior_sources' else '')
        destination.mkdir(parents=True, exist_ok=True)
        log_path = destination / (source.stem + '.build.log')
        with log_path.open('w', encoding='utf-8') as log:
            for number in range(1, passes + 1):
                log.write(f'Pass {number}/{passes}\n')
                log.flush()
                result = subprocess.run(
                    [engine, '-no-shell-escape', '-interaction=nonstopmode',
                     '-halt-on-error', '-file-line-error',
                     '-output-directory=' + str(destination), source.name],
                    cwd=source.parent, stdout=log, stderr=subprocess.STDOUT)
                if result.returncode:
                    print(f'FAILED: {relative}. Read {log_path}', file=sys.stderr)
                    return result.returncode
        pdf = destination / (source.stem + '.pdf')
        data = pdf.read_bytes() if pdf.is_file() else b''
        if not data.startswith(b'%PDF-') or b'%%EOF' not in data[-1024:]:
            print(f'FAILED: incomplete PDF for {relative}. Read {log_path}', file=sys.stderr)
            return 1
        print(f'Built: {pdf}')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
