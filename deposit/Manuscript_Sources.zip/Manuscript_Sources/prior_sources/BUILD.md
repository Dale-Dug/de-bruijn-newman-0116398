# Publication sources — editorial R2

The self-contained .tex files are the authoritative typesetting sources. The .md files are readable exports of the revised .tex; build from .tex. No font files are included.

With TeX Live and standard packages, compile each .tex twice with pdflatex; compile Analytic_Foundations.tex three times for its contents. The main paper uses amsthm in addition to the packages listed in its preamble. The bibliography is contained in the .tex, so no BibTeX run is required.

Example:

    pdflatex -halt-on-error Correlated_Translated_Probes.tex
    pdflatex -halt-on-error Correlated_Translated_Probes.tex

The numerical programs and scientific evidence are not edited. These publication files are not inputs to the numerical acceptance. No DOI is invented. A reserved version DOI may be added before deposit followed by recompilation and the publication-only reseal script; this does not constitute rechecking the mathematics.
