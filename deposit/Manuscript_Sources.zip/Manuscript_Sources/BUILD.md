# Build the current publication PDFs

Run `python BUILD_PDFS.py` in this directory. This uses local `pdflatex` with shell escape disabled and makes three passes for each of the four current documents. It makes no network requests. The compiled PDFs appear in `build/`.

A TeX Live installation needs Latin Modern, AMS maths/theorem packages, mathtools, geometry, microtype, booktabs, tabularx, array, longtable, enumitem, fancyhdr, xurl and hyperref. Install packages through your normal TeX distribution; no font binaries are shipped here.

The four source names match the four current public PDFs: `Conditional_0116398`, `Matched_Source_Supplement`, `Further_Consequences`, `Verification_Guide`. Each bibliography is contained in its document, so no external BibTeX run or bibliography download is required. The standalone main `.tex` in the deposit is byte-identical to this copy.

`python BUILD_PDFS.py --include-prior` also builds the three unchanged source documents in `prior_sources`. Only the prior main paper and foundations are included as public reference PDFs; the earlier verification guide remains historical source material. The original prior PDFs may have different creation metadata from a local rebuild. Their status and the Gaussian/sharp-displacement corrections are explained in the current paper and guide.

The prior source texts are preserved verbatim. Current-result references, assumptions and ceilings are defined by the new paper, not the historical sources. PDF timestamps can differ on a later build; identical mathematical text and rendering, rather than identical PDF binary metadata, are the reconstruction criterion.
